/* -*- c++ -*- */
/* 
 * Copyright 2020 Ajani Blackwood.
 * 
 * This is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3, or (at your option)
 * any later version.
 * 
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 51 Franklin Street,
 * Boston, MA 02110-1301, USA.
 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <gnuradio/io_signature.h>
#include "Makethreetones_impl.h"

namespace gr {
  namespace Blackwood_3tone {

    Makethreetones::sptr
    Makethreetones::make(float sigFreqin1,float sigFreqin2,float sigFreqin3, float sigAmp1,float sigAmp2, float sigAmp3)
    {
      return gnuradio::get_initial_sptr
        (new Makethreetones_impl(sigFreqin1,sigFreqin2, sigFreqin3, sigAmp1,sigAmp2,sigAmp3));
    }

    /*
     * The private constructor
     */
    Makethreetones_impl::Makethreetones_impl(float sigFreqin1,float sigFreqin2,
                                    float sigFreqin3, float sigAmp1,
                                    float sigAmp2, float sigAmp3)
      : gr::sync_block("Makethreetones",
                            gr::io_signature::make(0 ,0 ,0),
              gr::io_signature::make(1, 1, sizeof(float))),
              d_sigFreqin1(sigFreqin1),
              d_sigFreqin2(sigFreqin2),
              d_sigFreqin3(sigFreqin3),
              d_sigAmp1(sigAmp1),
              d_sigAmp2(sigAmp2),
              d_sigAmp3(sigAmp3)
    {
      d_sampRate = 1000000.0f;
      //d_sigFreqin1 = 5000.0f;
/*       d_sigFreqin2 = 5000.0f;
      d_sigFreqin3 = 5000.0f;

      d_sigAmp1 = 30.0f;
      d_sigAmp2 = 30.0f;
      d_sigAmp3 = 30.0f; */
    
      d_phaseStep1 = d_sigFreqin1/d_sampRate*2.0f*M_PI;
      d_phaseStep2 = d_sigFreqin2/d_sampRate*2.0f*M_PI;
      d_phaseStep3 = d_sigFreqin3/d_sampRate*2.0f*M_PI;

      d_phaseAccum1 = 0.0f;
      d_phaseAccum2 = 0.0f;
      d_phaseAccum3 = 0.0f;

    }

    /*
     * Our virtual destructor.
     */
    Makethreetones_impl::~Makethreetones_impl()
    {
    }

    int
    Makethreetones_impl::work(int noutput_items,
        gr_vector_const_void_star &input_items,
        gr_vector_void_star &output_items)
    {
       //const int *in = (const int *) input_items[0];
      float *out = (float *) output_items[0];
      float tmp2Pi = 2.0f*M_PI;


      // Do <+signal processing+>

      for(int i=0; i<noutput_items;i++)
      {
        //phase accum 2pi*t

        out[i] = (1/(d_sigAmp1+d_sigAmp2 +d_sigAmp3)) *
                    (d_sigAmp1*cosf(d_phaseAccum1) + d_sigAmp2*cosf(d_phaseAccum2) + d_sigAmp3*cosf(d_phaseAccum3));
        d_phaseAccum1 += d_phaseStep1;
        d_phaseAccum2 += d_phaseStep2;
        d_phaseAccum3 += d_phaseStep3;

        if(d_phaseAccum1>tmp2Pi)
        {
          d_phaseAccum1 -= tmp2Pi;
        }

         if(d_phaseAccum2>tmp2Pi)
        {
          d_phaseAccum2 -= tmp2Pi;
        }

         if(d_phaseAccum3>tmp2Pi)
        {
          d_phaseAccum3 -= tmp2Pi;
        }


      }

      // Tell runtime system how many output items we produced.
      return noutput_items;
    }

  } /* namespace Blackwood_3tone */
} /* namespace gr */

